
print('Hello world')